// generated from rosidl_generator_c/resource/idl.h.em
// with input from action_msgs:srv/CancelGoal.idl
// generated code does not contain a copyright notice

#ifndef ACTION_MSGS__SRV__CANCEL_GOAL_H_
#define ACTION_MSGS__SRV__CANCEL_GOAL_H_

#include "action_msgs/srv/detail/cancel_goal__struct.h"
#include "action_msgs/srv/detail/cancel_goal__functions.h"
#include "action_msgs/srv/detail/cancel_goal__type_support.h"

#endif  // ACTION_MSGS__SRV__CANCEL_GOAL_H_
